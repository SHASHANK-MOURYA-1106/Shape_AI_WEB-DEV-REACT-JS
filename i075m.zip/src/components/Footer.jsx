import React from "react";
function Footer() {
  return (
    <footer>
      <p>copyright shape_ai @ {new Date().getFullYear()}</p>
    </footer>
  );
}
export default Footer;
